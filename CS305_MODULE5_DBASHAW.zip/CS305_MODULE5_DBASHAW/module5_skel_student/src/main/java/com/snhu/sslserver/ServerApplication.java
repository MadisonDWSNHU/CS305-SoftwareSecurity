package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }
}

@RestController
class ServerController {
    
    // RESTful endpoint to return hash of a unique data string
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Hello Devin/Madison Bashaw!"; 
        String hashValue = generateHash(data);
        
        return "<p>Data: " + data + "</p><p>Checksum (SHA-256): " + hashValue + "</p>";
    }

    // Method to generate hash using SHA-256
    private String generateHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); // Initialize SHA-256
            byte[] hashBytes = digest.digest(input.getBytes()); // Generate hash
            return bytesToHex(hashBytes); // Convert to hex
        } catch (NoSuchAlgorithmException e) {
            return "Error: Unable to generate hash.";
        }
    }

    // Convert byte array to hexadecimal string
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0'); // Ensure two-character representation
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
