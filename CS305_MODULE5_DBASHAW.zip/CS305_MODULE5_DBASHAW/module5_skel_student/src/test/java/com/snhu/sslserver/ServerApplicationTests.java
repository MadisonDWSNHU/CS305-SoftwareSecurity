package com.snhu.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.snhu.sslserver.ServerApplication;

@SpringBootTest(classes = ServerApplication.class)
public class ServerApplicationTests {

    @Test
    void contextLoads() {
        
    }
}

