package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
@RequestMapping("/api") 
class ServerController {

    @GetMapping("/hash")
    public String generateHash() {
        String data = "Nice to meet you world, my name is Devin/Madison Bashaw!";

        try {
            // computing SHA-256 hash
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(data.getBytes(StandardCharsets.UTF_8));

            // converting to hexadecimal
            String hashHex = String.format("%064x", new BigInteger(1, hashBytes));

            // return response
            return "<p>Data: " + data + "</p>" +
                   "<p>SHA-256 Hash: " + hashHex + "</p>";
        } catch (NoSuchAlgorithmException e) {
            return "<p>Something went wrong while generating hash.</p>";
        }
    }
}
